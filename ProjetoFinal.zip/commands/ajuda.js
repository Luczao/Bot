const Discord = require('discord.js');
const fs = require("fs"); 
exports.run = async (client, message, args) => {
    let prefixes = JSON.parse(fs.readFileSync("./prefixes.json", "utf8"));
    if(!prefixes[message.guild.id]){
        prefixes[message.guild.id] = {
            prefixes: config.prefix
        };
    }
let prefix = prefixes[message.guild.id].prefixes;
const embed = new Discord.MessageEmbed()
.setTitle("**<a:7403_whitecrown:782451151547007037>     The Kingdoom     <a:7403_whitecrown:782451151547007037>**")
.setDescription('**Comunidade Inovadora**')
.setURL('https://discord.gg/nSTeebhAV3')
.setColor("#1500FF")
.addField("Meu prefixo aqui:", `${prefix}`, false)
.setThumbnail('https://cdn.dribbble.com/users/635160/screenshots/2927182/royale_crown_goodbye_01_dribbble.gif')
.addField("Meus Comandos!", `${prefix}avatar\n${prefix}kiss\n${prefix}moeda\n${prefix}online\n${prefix}info\n${prefix}sugerir\n${prefix}saysugerir\n${prefix}soco`, false)

.setFooter('🧾 Siga as regras do Servidor e evite advertências e banimento! Dê *info para ver as infos do servidor!');
message.channel.send(embed)

}